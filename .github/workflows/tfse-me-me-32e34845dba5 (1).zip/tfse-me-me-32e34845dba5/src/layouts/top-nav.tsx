import { Header } from "./Header";

const TopNav = () => {
  return <Header />;
};

export default TopNav;

export const explorerConfig: {
  [key: number]: string;
} = {
  56: "https://bscscan.com/",
  97: "https://testnet.bscscan.com/",
};

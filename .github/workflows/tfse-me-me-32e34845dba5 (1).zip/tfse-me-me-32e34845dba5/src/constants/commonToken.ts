import tokens from "./tokens";

export const listCommonToken = [
  tokens.usdt,
  tokens.busd,
  tokens.btcb,
];

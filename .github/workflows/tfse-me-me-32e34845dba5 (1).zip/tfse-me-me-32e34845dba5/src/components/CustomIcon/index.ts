import HomeIcon from "./HomeIcon.tsx";

const icons = {
  home: HomeIcon,
};
export default icons;
